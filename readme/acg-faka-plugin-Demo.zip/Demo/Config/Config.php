<?php
declare (strict_types=1);

return [
    'STATUS' => '1',
    'KeyId' => 'FAFAB92C-DFDF-1221-DEA2-40A0E915EB10',
];