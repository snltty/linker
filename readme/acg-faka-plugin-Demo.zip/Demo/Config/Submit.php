<?php
declare (strict_types=1);

return [
    [
        "title" => "Key",
        "name" => "KeyId",
        "type" => "input",
        "placeholder" => "加密秘钥"
    ]
];