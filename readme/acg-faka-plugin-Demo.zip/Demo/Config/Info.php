<?php
declare(strict_types=1);

use App\Consts\Plugin;

return [
    Plugin::NAME => 'Linker',
    Plugin::AUTHOR => 'snltty',
    Plugin::WEB_SITE => '#',
    Plugin::DESCRIPTION => '下单成功后加密卡密',
    Plugin::VERSION => '1.0.0'
];